Notes for the smallk release:

      The cython interface (pysmallk) is working.
      All code compiled with gcc 6.2.0 and mpich MPI tools.
