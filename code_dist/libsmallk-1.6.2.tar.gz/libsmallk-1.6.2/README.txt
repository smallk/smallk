Notes for the smallk_gt release:

      The cython interface (pysmallk) is currently broken.

      These will be updated in a future release.

