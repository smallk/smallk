Notes for the RC3 release:

      The cython interface (pysmallk) is currently broken.
      The vagrant image is out of date and does not match the C++ code.

      These will be updated in a future release.

